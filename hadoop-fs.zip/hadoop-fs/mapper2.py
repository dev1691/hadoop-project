#!/usr/bin/env python3

import csv
import sys

#!/usr/bin/env python
"""mapper.py"""

import sys
A={}
# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # split the line into words
    words = line.split(',')
    #print the the platform and no of games in platform
    if words[3].isnumeric():
    	if words[3] in A :
    		A[words[3]]+=1
    	else:
    		A[words[3]]=1

for h in sorted(A):
	if h.isnumeric():
		print(h,'=',A[h])
