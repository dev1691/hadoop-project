#!/usr/bin/env python3

import csv
import sys

#!/usr/bin/env python
"""mapper.py"""

import sys
A={}
# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # split the line into words
    words = line.split(',')
    #print the the platform and no of games in platform
    if words[5] in A:
    	A[words[5]]+=1
    else:
    	A[words[5]]=1

for h in sorted(A):
	print(h,'=',A[h])
    
    
    

