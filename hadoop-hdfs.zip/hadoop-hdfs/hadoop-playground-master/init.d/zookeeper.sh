#!/bin/bash
exec /usr/hdp/current/zookeeper-server/bin/zkServer.sh start-foreground
