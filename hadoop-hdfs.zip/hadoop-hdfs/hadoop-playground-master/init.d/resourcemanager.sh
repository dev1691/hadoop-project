#!/bin/bash
sleep 10
exec /usr/bin/yarn resourcemanager
