#!/bin/bash
sleep 15
exec /usr/bin/yarn timelineserver
