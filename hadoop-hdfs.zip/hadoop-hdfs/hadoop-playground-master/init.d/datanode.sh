#!/bin/bash
sleep 5
exec /usr/bin/hdfs datanode
