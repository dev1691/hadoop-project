#!/bin/bash
sleep 15
exec /usr/bin/hbase regionserver start
